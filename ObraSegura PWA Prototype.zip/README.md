# ObraSegura - PWA de Serviços de Manutenção Residencial

## 📱 Sobre o Projeto

**ObraSegura** é um Progressive Web App (PWA) mobile-first que conecta clientes a profissionais de manutenção residencial de forma segura e confiável. O design é limpo, profissional e transmite confiança, utilizando a paleta de cores azul marinho (#1A2B45), branco e cinza claro.

## ✨ Funcionalidades Implementadas

### 1. **Autenticação e Cadastro**
- ✅ Tela de Login/Splash com integração social (Google/Facebook)
- ✅ Cadastro diferenciado para **Cliente** e **Profissional**
- ✅ Formulário completo de cadastro com validação
- ✅ Upload de documentos para profissionais

### 2. **Busca de Profissionais**
- ✅ Barra de busca inteligente
- ✅ Filtros rápidos por especialidade (Pedreiro, Laje, Pintor)
- ✅ Mapa interativo simplificado mostrando profissionais próximos
- ✅ Busca por localização e distância
- ✅ Lista de profissionais com avaliações e informações

### 3. **Perfil do Prestador**
- ✅ Header com foto, nome e selo de verificado
- ✅ Sistema de avaliações com estrelas (nota + comentários)
- ✅ Estatísticas (serviços, satisfação, tempo de resposta)
- ✅ Galeria de portfólio em grid 3x3
- ✅ Seção de comentários de clientes anteriores
- ✅ Informações sobre experiência e especialidade

### 4. **Solicitação de Orçamento**
- ✅ Campo detalhado para descrição do serviço
- ✅ Upload de fotos/vídeos do problema (com preview)
- ✅ Seleção de prazo desejado
- ✅ Campo opcional de orçamento estimado
- ✅ Dicas visuais para melhor experiência

### 5. **Chat e Propostas**
- ✅ Chat básico entre cliente e prestador
- ✅ Indicador de status online
- ✅ Card de orçamento destacado no chat
- ✅ Detalhamento de materiais e valores
- ✅ Informações sobre prazo de execução
- ✅ Botão "Aceitar e Pagar via App"
- ✅ Opções de solicitar ajuste ou recusar

### 6. **Visualização de Propostas**
- ✅ Lista completa de propostas recebidas
- ✅ Status visual (Aguardando, Aceita, Recusada)
- ✅ Comparação de valores
- ✅ Estatísticas de propostas
- ✅ Filtros e organização

### 7. **Dashboard do Cliente**
- ✅ Lista de serviços agendados
- ✅ Status do serviço (Em andamento, Agendado, Concluído)
- ✅ Status de pagamento (Retido, Liberado)
- ✅ Botão para liberar pagamento
- ✅ Acesso rápido ao chat
- ✅ Cards de resumo (agendados, retido, propostas, concluídos)

## 📐 Design e UX

### Mobile-First
- ✅ Design otimizado para smartphones (360px - 414px)
- ✅ Botões com altura mínima de 44px para fácil clique
- ✅ Interface touch-friendly
- ✅ Navegação por abas (bottom navigation)

### Responsividade
- ✅ **Mobile**: 360px - 767px (1 coluna, navegação inferior)
- ✅ **Tablet**: 768px - 1023px (2 colunas em algumas telas)
- ✅ **Desktop**: 1024px+ (sidebar lateral, múltiplas colunas)

### Desktop
- ✅ Sidebar de navegação lateral
- ✅ Layout expandido com mais colunas
- ✅ Aproveitamento de espaço horizontal
- ✅ Navegação persistente

## 🎨 Design System

### Cores
- **Primary**: #1A2B45 (Azul Marinho)
- **Background**: #FFFFFF (Branco)
- **Secondary**: #F3F4F6 (Cinza Claro)
- **Success**: Verde (#10B981)
- **Warning**: Laranja (#F59E0B)
- **Error**: Vermelho (#EF4444)

### Tipografia
- **Fonte**: Inter (Google Fonts)
- **Pesos**: 400 (Regular), 500 (Medium), 600 (Semibold), 700 (Bold)

### Ícones
- **Biblioteca**: Lucide React
- **Estilo**: Linha fina (strokeWidth: 1.5)

### Componentes
- Botões arredondados (rounded-xl)
- Cards com sombra suave
- Inputs com borda e foco destacado
- Badges de status coloridos
- Avatares circulares com gradiente

## 🗂️ Estrutura de Telas

```
/splash (Login inicial)
  ├── /signup-client (Cadastro de Cliente)
  └── /signup-provider (Cadastro de Profissional)

/home (Busca de Profissionais)
  └── /profile (Perfil do Prestador)
      └── /request (Formulário de Solicitação)
          └── /chat (Chat e Proposta)

/proposals (Lista de Propostas)

/dashboard (Meus Serviços)
  └── Navegação para chat/propostas

/profile (Perfil do Usuário - futuro)
```

## 🔧 Tecnologias Utilizadas

- **React 18.3.1**
- **TypeScript**
- **Tailwind CSS v4**
- **Lucide React** (ícones)
- **Vite** (build tool)

## 🚀 Como Executar

O projeto está configurado e pronto para uso no Figma Make. Todas as dependências já estão instaladas.

### Navegação
1. Inicie na tela de Splash/Login
2. Escolha entre Cliente ou Profissional para cadastro
3. Explore o fluxo completo:
   - Buscar profissionais
   - Ver perfil detalhado
   - Solicitar orçamento com fotos
   - Receber e visualizar propostas
   - Conversar via chat
   - Aceitar proposta
   - Acompanhar serviços no dashboard

## 📱 Casos de Uso

### Para Clientes (Maria)
1. Cadastra-se como cliente
2. Busca profissionais por especialidade e localização
3. Visualiza perfis com portfólio e avaliações
4. Envia solicitação com fotos do problema
5. Recebe e compara múltiplas propostas
6. Conversa com profissional via chat
7. Aceita orçamento e paga via app (pagamento retido)
8. Acompanha status do serviço
9. Libera pagamento após conclusão

### Para Profissionais (João)
1. Cadastra-se como profissional
2. Completa perfil com portfólio
3. Recebe solicitações de clientes
4. Visualiza detalhes e fotos do problema
5. Envia orçamento detalhado
6. Conversa com cliente via chat
7. Recebe confirmação e inicia serviço
8. Marca como concluído
9. Recebe pagamento liberado

## 🔐 Segurança

- Pagamentos retidos no app até conclusão
- Verificação de profissionais (selo verificado)
- Sistema de avaliações
- Chat seguro entre partes

## 📊 Métricas e Indicadores

- Avaliações por estrelas (1-5)
- Taxa de satisfação
- Tempo médio de resposta
- Número de serviços completados
- Status de pagamento em tempo real

## 🎯 Diferenciais

- ✅ Upload de fotos/vídeos direto na solicitação
- ✅ Pagamento seguro retido no app
- ✅ Comparação visual de múltiplas propostas
- ✅ Mapa interativo com profissionais próximos
- ✅ Chat integrado com cards de orçamento
- ✅ Design profissional e confiável
- ✅ Totalmente responsivo (mobile + desktop)

---

**Desenvolvido com foco em UX/UI e confiança** 🏗️✨
